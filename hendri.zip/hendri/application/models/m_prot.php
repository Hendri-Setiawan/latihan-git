<?php 

class M_prot extends CI_model
	{
		/*public $nilai1;
		public $nilai2;
		public $nilai3;*/
		public function ngitung($nilai1="3.14",$nilai2="10"){
		$nilai3 = $nilai1 * $nilai2 * $nilai2;
		$data = ['phi'=>$nilai1,'jari'=>$nilai2,'luas'=>$nilai3 ];	
		return $data;
		//return $this->load->view('v_opening2',$data,true);
		//$this->load->view('v_opening2',$data);
		}
	}

?>