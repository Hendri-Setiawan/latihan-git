<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_opening extends CI_Controller {

	public function index($nilai1="3.14",$nilai2="8")
	{
		$nilai3 = $nilai1 * $nilai2 * $nilai2;
		$data = ['phi'=>$nilai1,'jari'=>$nilai2,'luas'=>$nilai3, ];	
		$this->load->view('v_opening2',$data);
	}

}
