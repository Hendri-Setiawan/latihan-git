<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_opening extends CI_Controller {

	public function index($nilai1="17.6J.01",$nilai2="6",$nilai3="Teknologi & Informasi",$nilai4="Hendri Setiawan",$nilai5="17200281")
	{
		$data = ['kelas'=>$nilai1,'semester'=>$nilai2,'prodi'=>$nilai3,'nama'=>$nilai4,'nim'=>$nilai5];	
		$this->load->view('v_opening',$data);
	}

	public function skop($nilai1="3.14",$nilai2="10")
	{
		$nilai3 = $nilai1 * $nilai2 * $nilai2;
		$data = ['phi'=>$nilai1,'jari'=>$nilai2,'luas'=>$nilai3, ];	
		$this->load->view('v_opening2',$data);
	}

	public function skep($nilai1="3.14",$nilai2="8"){
		/*$nilai3 = $nilai1 * $nilai2 * $nilai2;
		$data = ['phi'=>$nilai1,'jari'=>$nilai2,'luas'=>$nilai3 ];*/
		//$this->load->model('m_prot','ngitung');
		$data = $this->m_prot->ngitung();
		$this->load->view('v_opening2',$data);
	}
}
