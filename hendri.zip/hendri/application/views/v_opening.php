<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Opening</title>
</head>
<body>
	<h1>Selamat Datang di kelas 17.6J.01</h1></br>
	<hr>
	NAMA 			:<b><?=$nama;?></b></br>
	KELAS			:<b><?=$kelas;?></b></br>
	NIM				:<b><?=$nim;?></b></br>
	Semester 		:<b><?=$semester;?></b></br>
	Program Studi 	:<b><?=$prodi;?></b></br>
	<b><a href="<?=site_url("c_opening/skep");?>">Tugas Menghitung lingkaran</a></b></br>
</body>
</html>