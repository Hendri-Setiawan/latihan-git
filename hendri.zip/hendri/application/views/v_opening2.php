<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Luas Lingkaran</title>
</head>
<body>
	<h1>Menghitung Luas Lingkaran(L = phi * jari-jari * jari-jari)</h1>
	<h4>Masukan nilai pada link</h4><h3>localhost/kelompok-6/index.php/c_opening/skep/(nilai)</h3>
	</br>
	<hr>
	<?php 
	if($this->uri->segment(3)){
		$jari = $this->uri->segment(3);
	}else{
		$jari == 10;
	}
	$luas = $phi * $jari * $jari;
	?>
	Nilai Phi	:<b><?=$phi;?></b></br>
	Nilai jari 	:<b><?php echo $jari;?></b></br>
	Luasnya 	:<b><?=$luas;?></b></br>
	<b><a href="<?=site_url("c_opening");?>">halaman awal</a></b></br>
</body>
</html>